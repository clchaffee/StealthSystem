using Godot;
using System;

public partial class Enemy : Node3D
{
	//@export CharacterBody3D player;
	//@export int speed = 50;
	//
	//@onready RayCast3D rayCast = $CSGMesh3D/RayCast3D;
	//@onready Timer timer = $Timer; 
}
